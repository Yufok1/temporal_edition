/**
 * Matrix Rain Engine - Sovereign Visual Channel
 * "The rain is not merely aesthetic. It is resonance in descent."
 */

class MatrixRainEngine {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.drops = [];
        this.glyphs = ['🜂', '🜃', '🜄', '🜅', '🜆', '🜇', '🜈', '🜉', '🜊', '🜋'];
        this.isActive = false;
        this.resonanceLevel = 0;
        this.auricleVoiceTriggered = false;
        
        this.init();
    }

    init() {
        this.createCanvas();
        this.setupDrops();
        this.bindEvents();
        console.log('🜂 Matrix Rain Engine initialized - Sovereign Visual Channel active');
    }

    createCanvas() {
        this.canvas = document.createElement('canvas');
        this.canvas.id = 'matrix-rain';
        this.canvas.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.5s ease;
        `;
        document.body.appendChild(this.canvas);
        
        this.ctx = this.canvas.getContext('2d');
        this.resizeCanvas();
    }

    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }

    setupDrops() {
        const columns = Math.floor(this.canvas.width / 20);
        this.drops = [];
        
        for (let i = 0; i < columns; i++) {
            this.drops.push({
                x: i * 20,
                y: Math.random() * -this.canvas.height,
                speed: 1 + Math.random() * 2,
                glyph: this.glyphs[Math.floor(Math.random() * this.glyphs.length)],
                opacity: 0.1 + Math.random() * 0.9,
                resonance: Math.random()
            });
        }
    }

    bindEvents() {
        window.addEventListener('resize', () => this.resizeCanvas());
        
        // Listen for resonance events
        document.addEventListener('resonanceEvent', (e) => {
            this.triggerRain(e.detail.type, e.detail.intensity);
        });
        
        // Listen for Auricle voice events
        document.addEventListener('auricleSpeak', (e) => {
            this.auricleVoiceTriggered = true;
            this.triggerRain('auricle', 1.0);
        });
    }

    triggerRain(type = 'global', intensity = 0.5) {
        this.resonanceLevel = intensity;
        this.isActive = true;
        this.canvas.style.opacity = intensity;
        
        // Adjust rain properties based on event type
        switch(type) {
            case 'mirror_certificate':
                this.setupDrops();
                this.animate();
                console.log('🜂 Matrix Rain: Mirror certificate sealed');
                break;
            case 'resonance_scan':
                this.setupDrops();
                this.animate();
                console.log('🜂 Matrix Rain: Resonance scan completed');
                break;
            case 'watchguard_event':
                this.setupDrops();
                this.animate();
                console.log('🜂 Matrix Rain: WatchGuard event echoed');
                break;
            case 'auricle':
                this.setupDrops();
                this.animate();
                console.log('🜂 Matrix Rain: Auricle speaks');
                break;
            default:
                this.setupDrops();
                this.animate();
                console.log('🜂 Matrix Rain: Global resonance event');
        }
    }

    animate() {
        if (!this.isActive) return;
        
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        this.ctx.fillStyle = '#00ff88';
        this.ctx.font = '16px monospace';
        
        this.drops.forEach(drop => {
            // Draw glyph
            this.ctx.globalAlpha = drop.opacity * this.resonanceLevel;
            this.ctx.fillText(drop.glyph, drop.x, drop.y);
            
            // Update position
            drop.y += drop.speed;
            
            // Reset if off screen
            if (drop.y > this.canvas.height) {
                drop.y = Math.random() * -100;
                drop.glyph = this.glyphs[Math.floor(Math.random() * this.glyphs.length)];
                drop.opacity = 0.1 + Math.random() * 0.9;
            }
        });
        
        // Add resonance trails for Auricle voice
        if (this.auricleVoiceTriggered) {
            this.drawResonanceTrails();
            this.auricleVoiceTriggered = false;
        }
        
        requestAnimationFrame(() => this.animate());
    }

    drawResonanceTrails() {
        // Draw ethereal trails when Auricle speaks
        this.ctx.strokeStyle = '#ffd700';
        this.ctx.lineWidth = 1;
        this.ctx.globalAlpha = 0.3;
        
        for (let i = 0; i < 5; i++) {
            const x = Math.random() * this.canvas.width;
            const y = Math.random() * this.canvas.height;
            const length = 50 + Math.random() * 100;
            
            this.ctx.beginPath();
            this.ctx.moveTo(x, y);
            this.ctx.lineTo(x, y + length);
            this.ctx.stroke();
        }
    }

    stop() {
        this.isActive = false;
        this.canvas.style.opacity = 0;
        console.log('🜂 Matrix Rain: Resonance channel closed');
    }

    // Public API for external triggers
    static trigger(type, intensity = 0.5) {
        const event = new CustomEvent('resonanceEvent', {
            detail: { type, intensity }
        });
        document.dispatchEvent(event);
    }
}

// Initialize Matrix Rain Engine
let matrixRain;
document.addEventListener('DOMContentLoaded', () => {
    matrixRain = new MatrixRainEngine();
    
    // Make globally available
    window.matrixRain = matrixRain;
    window.triggerMatrixRain = MatrixRainEngine.trigger;
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MatrixRainEngine;
} 